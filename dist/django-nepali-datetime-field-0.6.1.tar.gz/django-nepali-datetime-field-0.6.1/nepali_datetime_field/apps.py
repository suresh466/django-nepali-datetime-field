from django.apps import AppConfig


class NepaliDatetimeFieldConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nepali_datetime_field'
